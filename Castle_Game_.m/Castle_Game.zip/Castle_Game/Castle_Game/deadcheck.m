if MonsterHP<=0 %------Check if monster is dead
        clc
        clear sound
        MonsterHP=0;
        run('Aftermath')
        Playerturn=1;        
end
if Health<=0
    clc
    clear sound
    Health = -1;
    run('Aftermath')
    Playerturn=1;
end