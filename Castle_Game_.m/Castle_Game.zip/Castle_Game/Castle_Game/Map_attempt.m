%Optional: If room not discovered, then don't show it yet
%Optional: Find a map that highlights all the possible rooms where monsters
%are
figure(2)
title('You are here!','FontSize',15)
box off
axis off
rectangle('Position',[1 0 9 6],'FaceColor',[0.70 0.5 0.042], 'EdgeColor','r')
axis fill
rectangle('Position',[2 3 1 1],'FaceColor',[0 0 0],'EdgeColor','w') %Left room
rectangle('Position',[1 3 1 1],'FaceColor',[0 0 0],'EdgeColor','w') %Leftmost room
rectangle('Position',[3 3 1 1],'FaceColor',[0 0 0],'EdgeColor','w') %Two-way room
rectangle('Position',[3 1 1 2],'FaceColor',[0 0 0],'EdgeColor','w') %Beginning Room
rectangle('Position',[4 1 1 1],'FaceColor',[0 0 0],'EdgeColor','w') %Potion Chest
rectangle('Position',[4 3 2 1],'FaceColor',[0 0 0],'EdgeColor','w') %Tri room
rectangle('Position',[6 3 1 1],'FaceColor',[0 0 0],'EdgeColor','w') %Straight room
rectangle('Position',[5 2 2 1],'FaceColor',[0 0 0],'EdgeColor','w') %Trap Room
rectangle('Position',[5 4 2 1],'FaceColor',[0 0 0],'EdgeColor','w') %Left potion room
rectangle('Position',[7 2 1 3],'FaceColor',[0 0 0],'EdgeColor','w') %Final Room
rectangle('Position',[8 2 2 3],'FaceColor',[0 0 0 ],'EdgeColor','w') %Boss Room
radius = 0.1;

Found=0;
while Found==0
    if Room==1
       X=3.5;
       Y=1.5;
    elseif Room==2
        X=3.5;
        Y=3.5;
    elseif Room==3
        X=2.5;
        Y=3.5;        
    elseif Room==4
        X=1.5;
        Y=3.5;        
    elseif Room==5
        X=4.5;
        Y=3.5;        
    elseif Room==6
        X=5.5;
        Y=4.5;
    elseif Room==7
        X=5.5;
        Y=2.5;        
    elseif Room==8
        X=6.5;
        Y=3.5;  
    elseif Room==9
        X=7.5;
        Y=3.5;
    else
        fprintf('Sorry! We couldn''t find you!')
    end
Found=1;
center = [X Y];
end
Room_name={'After fight room','Fight Room','Left Hall','Mirror Room','Tri Room','First Floor Bathroom...','Painting Room','Sitting Room','Last Room'};
Room_nam=transpose(Room_name);
Room_na=[Room_nam{Room}];
viscircles(center,radius,'Color','g');
fprintf('You are cureently in the %s\n',Room_na)
input('Press enter to exit the map','s')
close(figure(2))



