if Type==1
   fprintf('This monster will pre-emptively attack every thrid turn.\n')
   input('Make sure to defend on your first action when this occurs.\n','s')
elseif Type==2
    fprintf('Armor type: Light\nWill premptively attack: Every 2 turns\n')
    input('Tip: Avoid defending unless a premptive strike will occur.\n','s')
elseif Type==3
    if key==0
    fprintf('Why didn''t you look for a key before?\n')
    elseif key==1
        fprintf('There was a freaking key in your pocket.\n%s, Are you blind as well?\n',name)
    end
    fprintf('Anyway...\n')
    input('\nThe monster''s does not attack pre-emptively but has a strong attack.\nRemember to defend.\n','s')
elseif Type==4
    fprintf('\n The mosnter has a strong attack, but does not pre-emptively attack\n')
    input('Try all options.\n')
elseif Type==5
    fprintf('When he begins to prepare his special attack remember to defend.\n') 
    fprintf('His high focus on you will make bombs difficult to use...\n')
    input('Remember that bombs are for special events.\n','s')
    
end
