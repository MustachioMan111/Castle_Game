Battle_Boss = 1;
checkoff = 0;
sword = 0;
defense = 0;
%Monster elements
Monster_att = 0;
MonsterHP = 150;
Monster_Defend = 0;
Once=0;
Turn =0;
Playerturn = 0;
Type=5;
%%%%%%TAKE THIS OUT BEFORE FINISH%%%%%
%Special = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc
Fire_Start=0;
if Fire==0
imshow('Boss_Monster3.jpg','InitialMagnification','fit')
end
if Health >0 || MonsterHP >0
run('Boss_Song1') 
end
while Health >0 && MonsterHP >0
        if Health<10
            %I have to find a way to play low health, but not constantly
            %clear the sound, just the battle song music
        fprintf('Warning!!! You''re at very low health!!!!\n')
        end
while Playerturn==0
run('Player_Options')

        if rem(Turn,4)==0 && Strength_Potion_Turn==0 && Turn ~=0 && sword>=30
           fprintf('But the statue predicts your movements and guards from your attack!\n')
           sword = 3;
        end
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if sword==30 || sword==40
        if Fire>=1
            Fire=0;
            fprintf('\n\nThe statue is knocked back!\n')
            fprintf('The blast of the bomb sends smoke and sut around!\n') 
            input('The fire is cleared!','s');
            imshow('Boss_Monster3.jpg','InitialMagnification','fit')
        else
            fprintf('\n\nThe statue sees that you throw the bomb!\n')
            fprintf('He bats it out of his way and is not effected!\n')
            input('He''s too focused on you right now...\nYou''ll have to wait until he''s distracted on something else.\n')
            sword=0;
        end
    end



end

    if sword ==0
        enter = input('End of your turn\n', 's');
        clc
    else
        response = fprintf('You do %4.2f damage!\n',sword);
        enter = input('End of your turn\n', 's');
        clc
        MonsterHP = MonsterHP-sword;
       
    end
    if Fire>=1
        if Fire==1
        fprintf('But the fire is spreading...\n')
        input('You lose 3 HP!','s');
        Health= Health-3;
        Fire=Fire+1;
        elseif Fire>1
        fprintf('But the fire is blazing!\n')
        fprintf('You lose 5 HP!\n')
        input('There must be something you can use to clear the fire...','s');
        Health=Health-5;
        end
    end   

    %Simple check statement to confirm player is still alive
    if Health<=0
    clc
    clear sound
    run('Aftermath_Boss')
    Health=-1;
    break
    end
   fprintf('The statue is about to attack!\n')
   fprintf('Choose your second action\n\n')
run('Player_Options_2')  
    Playerturn=0;
%checkoff is set to zero at the start of the monster's turn
%% Monster Parameters
Special=Special+1; %---Charge for monster's special attack

%Boss's actions change once health is less than 75 HP
%He sets room on fire
if MonsterHP<75
    if Fire==0 && Once==0 %This IF is initiated only once
    clc
    clear sound
    fprintf('The statue is getting weaker.\n')
    input('A chunck of stone falls off the statue...','s');
    input('It its anger it raises it''s arms...\nIt closes it''s eyes and focuses intently...\n','s');
    input('A fire engulfs the room!\n\n','s');
    run('Boss_Song1_Low')
    Fire=1; %---Variable sets room on fire
    imshow('Boss_Monster4.jpg','InitialMagnification','fit')
    Once=1; %This specific IF is only initiated once
    %IF the Boss has set the room on fire previously. Then it will skip to
    %this action rather than to the other one
    elseif Once==1 && Fire==0
    % For all other instances when the room is set on fire
    clc
    fprintf('The statue raises it''s arms again...\n');
    input('The fires have come back!\n','s');
    imshow('Boss_Monster4.jpg','InitialMagnification','fit')
    Fire=1;
    
    end
end
if MonsterHP <=0
    clc
    clear sound
    MonsterHP = 0;
    run('Aftermath_Boss')
    break
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if defense==1 %----If the player defends, the boss does almost no damage
    if Special==5
    elseif defense_second==1
        Monster_att = randi([5 6],1);
        
    else
    Monster_att = randi([1 2],1);
    fprintf('The statue swings!\n');
    fprintf('But you defended\n');
    input('He pounds it against the shield!','s')
    end
%If Player doesnt defend Monster does damage
elseif defense==0 && Special~=5
    enter = input('The statue swings it''s sword!\n','s');
    Monster_att=randi([9 11],1);
end
if defense_second==1
    Monster_att = randi([5 6],1);
end
%% Special attack charge
%Special attack is done every 5 turns
%If the player defended before the attack, then only 3 HP is lost
%If the player did not defend, then 20 HP is lost
if Special==5
    clc
    fprintf('The statue''s sword floats over it''s head\n')
    fprintf('It fires at you with incredible speed!\n')
    Special=0; %----Special attack counter resets after attack is done
    if defense==0
        input('\nYou were unprepared for his attack!\n','s')
        Monster_att=20;        
    elseif defense==1
        fprintf('You prepared your shield for his attack!')
        input('The sword pounds against the shield.\nYou fly back, but you''re mostly unscaved!\n','s')
        Monster_att=3;
    elseif defense_second==1
        input('You attempted to prepare by raising your sword/n but you were unable to fully against defend it!','s')
        Monster_att=20;
    end
end
%%
Health = (Health-Monster_att);
damage = fprintf('You lose %4.2f HP!\n',Monster_att);

        if sword ==0
        else
        fprintf('You counterattack.\n')
        response = fprintf('You do %4.2f damage!\n',sword);
        MonsterHP = MonsterHP-sword;
        end

%A warning to the player that the next attack is a special attack
if Special==4
    fprintf('It looks like he''s preparing something...\nHe''s focused intently on you....\n')
    
end
%If player health is less than or equal to zero, then the aftermath is run.
%Since the aftermath would be for the player, it would be a player's loss
if Health<=0
    clc
    clear sound
    run('Aftermath_Boss')
    Health=-1;  
end
enter = input('Your turn\n','s');
clc
end
Battle = 0;
clear sound