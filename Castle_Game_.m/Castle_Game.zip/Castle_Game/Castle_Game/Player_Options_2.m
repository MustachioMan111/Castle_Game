Playerturn=0;
if defense==0
   while Playerturn==0
        fprintf('Current turn: %4.0f\n',Turn)
        fprintf('Current HP: %4.1f\n',Health);
        fprintf('Monster''s health: %4.2f\n',MonsterHP);
        fprintf('Battle Options: Counterattack, Defend, Inspect\n\n')
        fight = strtrim(lower(input('Second Action:','s')));
        

        if strfind(fight,'attack')
    Playerturn = 1;
%     attack = input('\nYou swing your sword\n','s');
    sword = randi([low high],1);
    %attack parameters
%             if sword == high
%             fprintf('You swing with all your might! Critical damage!\n');
%                 elseif sword == low
%                 fprintf('You lightly tap the monster...\n');
%                 elseif sword == low+1
%                 fprintf('You misstep when attacking...\n');
%             end
            if defense ==1
                fprintf('You charged your attack!\n');
                sword = randi([low+5 low+5],1);
                defense = 0;
            end
        elseif strfind(fight,'defend')
            defense_second= 1;
            fprintf('You quickly raise your sword in defense.\n');
            sword = 0;
            Playerturn=1;
        elseif strfind(fight,'inspect')
            Playerturn=1;
            run('Monster_Type')
            defense = 0;
            sword = 0;
        elseif strfind(fight,'barley')
            sword=5000;
            Playerturn=1;
        else
                clc
                Playerturn=0;
        end   
    end %-----------Playerturn Action 1 Finished
    Turn = Turn+1;
elseif defense==1
    Turn = Turn+1;
    Playerturn=1;
    clc
end

        if Strength_Potion_Turn==1
           sword =sword+10;
           Strength_Potion_Turn=Strength_Potion_Turn+1;
        elseif Strength_Potion_Turn==2
           sword =sword+10;
           Strength_Potion_Turn=Strength_Potion_Turn+1;
        elseif Strength_Potion_Turn==3
           sword =sword+10;
           Strength_Potion_Turn=Strength_Potion_Turn+1;
        elseif Strength_Potion_Turn==4
           sword =sword+10;
           Strength_Potion_Turn=Strength_Potion_Turn+1;
        elseif Strength_Potion_Turn==5
           sword =sword+10;
           Strength_Potion_Turn=Strength_Potion_Turn+1;
       elseif Strength_Potion_Turn==0
       elseif sword == high
        end