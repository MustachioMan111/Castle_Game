    while Playerturn==0
        if Type~=4
        fprintf('Current turn: %4.0f\n',Turn)
        fprintf('Current HP: %4.2f\n',Health);
        fprintf('Monster''s health: %4.2f\n',MonsterHP);
        fprintf('Battle Options: Attack, Defend, Inventory, Inspect\n\n')
        fight = strtrim(lower(input('First Action:','s')));
        elseif Type==4
           clc
           fprintf('Current turn: %4.0f\n',Turn)
           fprintf('Current HP: %4.2f\n',Health);
           fprintf('Monster''s health: %4.2f\n',MonsterHP);
           fprintf('Battle Options: Attack, Defend, Inventory, Inspect, Chair\n\n')
           fight = strtrim(lower(input('First Action:','s')));
       end
        
        if strfind(fight,'attack')
    Playerturn = 1;
    attack = input('\nYou swing your sword\n','s');
    sword = randi([low high],1);
    %attack parameters
            if defense ==1
                fprintf('You charged your attack!\n');
                sword = randi([low+5 high+5],1);
                defense = 0;
            end
        elseif strfind(fight,'defend')
            defense = 1;
            fprintf('You put up your shield. Your defense increases\n');
            fprintf('Your attack increases next turn\n');
            sword = 0;
            Playerturn=1;
        elseif strfind(fight,'inspect')
            Playerturn=1;
            run('Monster_Type')
            defense = 0;
            sword = 0;
        elseif strfind(fight,'inventory')
            defense = 0;
            run('Inventory')
            Playerturn=1;
            %\/ This if statement ensures that the low health battle song
            %does not play when the player is not at low health. Since
            %healing brings up health, this if statement returns the song
            %to normal
                if Potion_use==1 && Battle_Boss==0 %If the player heals during a normal battle, the regular battle song will occur
                clear sound
                run('Battle_song')
                elseif Potion_use==1 && Battle_Boss==1 && Once==0 %If the player heals during the boss battle, the boss song will occur
                clear sound
                run('Boss_Song1')
                end
        elseif strfind(fight,'barley')
            sword=5000;
            Playerturn=1;
        else
                clc
                Playerturn=0;
         if Type==4
             if strfind(fight,'chair')
                 Playerturn = 1;
                 defense = 0;
                     if chair==0
                        sword=15;
                        chair=1;
                        input('\nYou throw a chair.','s')
                        input('The sheer ridiculousness of your action stuns the monster!\n','s')
                        %No checkoff b/c extra turn
                        response = fprintf('You do %4.2f damage!\n',sword);
                        MonsterHP=MonsterHP-sword;
                        clc
                        elseif chair==1
                        input('You throw a chair.\n','s')
                        input('The monster is not effected now.\n It''s just angry.','s');                        
                        sword=3;
                    end
                 
             end
         end
                
        end
    end %-----------Playerturn Action 1 Finished
    
        if Strength_Potion_Turn==1
           sword =sword+10;
           Strength_Potion_Turn=Strength_Potion_Turn+1;
        elseif Strength_Potion_Turn==2
           sword =sword+10;
           Strength_Potion_Turn=Strength_Potion_Turn+1;
        elseif Strength_Potion_Turn==3
           sword =sword+10;
           Strength_Potion_Turn=Strength_Potion_Turn+1;
        elseif Strength_Potion_Turn==4
           sword =sword+10;
           Strength_Potion_Turn=Strength_Potion_Turn+1;
        elseif Strength_Potion_Turn==5
           sword =sword+10;
           Strength_Potion_Turn=Strength_Potion_Turn+1;
       elseif Strength_Potion_Turn==0
       elseif sword == high
        fprintf('You swing with all your might! Critical damage!\n');
        end    
    if defense==1
        sword=0;
        
    elseif defense_second==1
        sword=0;
        
    elseif strfind(fight,'inspect')
        sword=0;
        
    end