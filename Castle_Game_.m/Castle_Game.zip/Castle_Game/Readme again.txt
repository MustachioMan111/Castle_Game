This game doesn't have a real name yet, but lets call it Castle Game for now.

Some of the text ingame will only continue once you press enter, it will generally be found when the text seems to stop.
The title of your character changes each time you start the game.
You can't completely leave the castle yet, but you can go back to where you first entered.

Warning: Matlab sounds and music is louder than most applications, so make sure to slightly turn down your volume. ( It's not too much louder! You won't go deaf, I promise!)


This was created by Daniel Graciano using MatLab
Email: dmgraciano@gmail.com

