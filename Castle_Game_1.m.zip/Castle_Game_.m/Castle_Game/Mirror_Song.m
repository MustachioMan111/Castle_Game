  amp=1;
f=4000;
%True speed of song will be 0.35
value = [0:(1/f):0.35];
value8 = [0:(1/f):0.95];
value_fast = [0:(1/f):0.3];
Rest = (amp*sin(2*pi*0*0:(1/f):0.05));
Rest1 = (amp*sin(2*pi*0*0:(1/f):0.1));
Rest2 = (amp*sin(2*pi*0*0:(1/f):0.2));
Rest3 = (amp*sin(2*pi*0*0:(1/f):0.3));
Rest4 = (amp*sin(2*pi*0*value));
Rest45 = (amp*sin(2*pi*0*0:(1/f):0.45));
Rest5 = (amp*sin(2*pi*0*0:(1/f):0.5));
Rest7 = (amp*sin(2*pi*0*0:(1/f):0.7));
RestW = (amp*sin(2*pi*0*0:(1/f):1.3));
RestW1 = (amp*sin(2*pi*0*0:(1/f):1.5));
RestH = (amp*sin(2*pi*0*0:(1/f):0.025));

C2 = (amp*sin(2*pi*65.41*value));
C2SHP = (amp*sin(2*pi*69.30*value));
D2 = (amp*sin(2*pi*73.42*value));
E2FLT = (amp*sin(2*pi*77.78*value));
E2 = (amp*sin(2*pi*82.41*value)); 
F2 = (amp*sin(2*pi*87.31*value));
F2SHP = (amp*sin(2*pi*92.50*value));
G2 = (amp*sin(2*pi*98*value));
G2SHP = (amp*sin(2*pi*103.8*value));
A2 = (amp*sin(2*pi*110*value));
B2FLT = (amp*sin(2*pi*116.5*value));
B2 = (amp*sin(2*pi*123.5*value));

C3 = (amp*sin(2*pi* 130.8*value));
C3SHP = (amp*sin(2*pi*138.6*value));
D3 = (amp*sin(2*pi*146.8*value));
E3FLT = (amp*sin(2*pi*155.6*value));
E3 = (amp*sin(2*pi*164.8*value));
F3 = (amp*sin(2*pi*174.6*value));
F3SHP = (amp*sin(2*pi*185*value));
G3 = (amp*sin(2*pi*196*value));
G3SHP = (amp*sin(2*pi*207.7*value));
A3 = (amp*sin(2*pi*220*value));
B3 = (amp*sin(2*pi*246.9*value));
B3FLT = (amp*sin(2*pi*233.1*value));

B3FLT8 = (amp*sin(2*pi*233.1*value8));

C4 = (amp*sin(2*pi*261.6*value));
C4SHP = (amp*sin(2*pi*277.2*value));
D4 = (amp*sin(2*pi*293.7*value));
E4FLT = (amp*sin(2*pi*311.1*value)); 
E4 = (amp*sin(2*pi*329.6*value)); 
F4 = (amp*sin(2*pi*349.2*value));
F4SHP= (amp*sin(2*pi*370*value));
G4 = (amp*sin(2*pi*392*value));
G4SHP = (amp*sin(2*pi*415.3*value));
A4 = (amp*sin(2*pi*440*value));
B4FLT = (amp*sin(2*pi*466.2*value));
B4 = (amp*sin(2*pi*493.9*value));

C5 = (amp*sin(2*pi*523.3*value));
C5SHP = (amp*sin(2*pi*554.4*value));
D5 = (amp*sin(2*pi*587.3*value));
E5FLT = (amp*sin(2*pi*622.25*value));
E5 = (amp*sin(2*pi*659.25*value));
F5 = (amp*sin(2*pi*698.46*value));
F5SHP = (amp*sin(2*pi*739.99*value));
G5 = (amp*sin(2*pi*783.99*value));
G5SHP = (amp*sin(2*pi*830.61*value));
A5 = (amp*sin(2*pi*880*value));
B5FLT = (amp*sin(2*pi*932.33*value));
B5 = (amp*sin(2*pi*987.77*value));

C6 = (amp*sin(2*pi*1047*value));
C6SHP = (amp*sin(2*pi*1109*value));
D6 = (amp*sin(2*pi*1175*value));
E6FLT = (amp*sin(2*pi*1245*value));
E6 = (amp*sin(2*pi*1319*value));
F6 = (amp*sin(2*pi*1397*value));
F6SHP = (amp*sin(2*pi*1480*value));
G6 = (amp*sin(2*pi*1568*value));
G6SHP = (amp*sin(2*pi*1661*value));
A6 = (amp*sin(2*pi*1760*value));
B6FLT = (amp*sin(2*pi*1865*value));
B6 = (amp*sin(2*pi*1976*value));

C7 = (amp*sin(2*pi*2093*value));
C7SHP = (amp*sin(2*pi*2217*value));
D7 = (amp*sin(2*pi*2349*value));
E7FLT = (amp*sin(2*pi*2489*value));
E7 = (amp*sin(2*pi*2637*value));
F7 = (amp*sin(2*pi*2794*value));
F7SHP = (amp*sin(2*pi*2960*value));
G7 = (amp*sin(2*pi*3136*value));

C8 = (amp*sin(2*pi*4186*value));
%Make sure to save as something else when done with song
%Remember: D flat is C sharp; D sharp is E flat; A sharp is B flat
D5L= (amp*sin(2*pi*587.3*value));

a = [B4FLT G4 D5 D5 B4FLT G4 E5 E5 B4FLT G4 F5 F5 B4FLT G4 E5 E5 B4FLT G4 D5 D5 B4FLT G4 E5 E5 B4FLT G4 G5 G5 B4FLT F4SHP F5SHP F5SHP];
a_1 = [Rest4 Rest4 Rest4 Rest4 Rest4 Rest4 Rest4 Rest4 G4 G4 Rest4 A4 A4 Rest4 B4FLT B4FLT D5 D5 Rest4 Rest4 Rest4 Rest4 Rest4 Rest4 F4SHP F4SHP Rest4 G4 G4 Rest4 A4 A4];
a_2 = [B5FLT G5 D5 B4FLT B5FLT G5 D5 B4FLT A5 F5SHP C5 A4 A5 F5SHP C5 A4];
a_3 = [Rest4 Rest4 Rest4 Rest4 Rest4 Rest4 Rest4 Rest4 G4 G4 Rest4 A4 A4 Rest4 B4FLT B4FLT C5 C5 Rest4 Rest4 Rest4 Rest4 Rest4 Rest4 C5 C5 Rest4 D5 D5 Rest4 E5FLT E5FLT];
a_4 = [G5 D5 G5 D5, G5 D5 G5 D5, F5SHP D5 F5SHP D5 F5SHP D5 G5 D5];
a_5 = [F5 F5 F5 E5FLT E5FLT E5FLT D5 D5 E5FLT E5FLT E5FLT D5 D5 D5 C5 C5 B4 B4 B4 B4 B4 B4 B4 B4 C5 C5 C5 C5 C5 C5,E5FLT E5FLT F5 F5 F5 E5FLT E5FLT E5FLT D5 D5 E5FLT E5FLT E5FLT D5 D5 D5 C5 C5 D5 D5 D5 D5 D5 D5 D5 D5 G5 G5SHP G5 G5SHP G5 Rest4 Rest4];


a_x = [G5SHP E5FLT Rest4 G5SHP E5FLT Rest4 G5 E5FLT F5SHP C5SHP Rest4 F5SHP C5SHP Rest4 F5SHP C5SHP E5 B4 Rest4 E5 B4 Rest4 Rest4 Rest4 C5SHP E5FLT B4FLT G4 E4FLT, E5FLT B4FLT G4 E4FLT];
a_y = [G5SHP G5SHP G5SHP B5FLT B5 C6SHP C6SHP B5 C6SHP E6FLT E6FLT C6SHP C6SHP B5 G5SHP G5SHP F5SHP F5SHP G5SHP G5SHP B5 B5 C6SHP B5 B5FLT E6FLT E6 E6FLT E6 E6FLT];

b = [G2 G2 Rest4 Rest4 B2FLT B2FLT Rest4 Rest4 A2 A2 Rest4 Rest4 F2SHP F2SHP Rest4 Rest4, G2 G2 Rest4 Rest4 B2FLT B2FLT Rest4 Rest4 D3 D3 Rest4 Rest4 D2 D2 B2FLT A2];
b_1 = [G2 D2 G2 D2, G2 D2 G2 D2, G2 D2 G2 D2, G2 D2 G2 D2 B2FLT G2 B2FLT G2 B2FLT G2 B2FLT G2 B2FLT G2 F2SHP E2 F2SHP D2 D2 D2];
b_2 = [B2FLT G2 B2FLT G2 B2FLT G2 B2FLT G2 D3 E3FLT D3 F2SHP D3 E3FLT D3 F2SHP];
b_3 = [G2 D2 B2FLT A2, G2 D2 B2FLT A2, G2 D2 B2FLT A2, G2 D2 B2FLT A2, B2FLT G2 D3 G2 B2FLT G2 D3 G2, A2 F2SHP D3 F2SHP A2 F2SHP D3 F2SHP];
b_4 = [G2 B2FLT D3 D3, G2 B2FLT D3 D3 D3 E3FLT F2SHP F2SHP G2 F2 E2FLT D2];
b_5 = [C3 C3 C3 B2FLT B2FLT B2FLT A2 A2 B2FLT B2FLT B2FLT A2 A2 A2 G2 G2 F2SHP F2SHP F2SHP F2SHP F2SHP F2SHP F2SHP F2SHP G2 G2 G2 G2 G2 G2, B2FLT B2FLT C3 C3 C3 B2FLT B2FLT B2FLT A2 A2 B2FLT B2FLT B2FLT A2 A2 A2 G2 G2 A2 F2SHP A2 F2SHP A2 F2SHP A2 F2SHP D3 Rest4 D3 Rest4 D3 Rest4 Rest4];

%b_x = [D3 G2 Rest4 D3 G2 Rest4 D3 G2 C3SHP G2 C3SHP G2];
%b_l = [B3FLT B3FLT Rest4 G3 G3 Rest4 A3 A3 Rest4 F3SHP F3SHP]

a_6 = [G5 D5 Rest4 G5 D5 Rest4 G5 G5 A5 C5 Rest4 A5 C5 Rest4 A5 A5 B5FLT B4FLT Rest4 B5FLT B4FLT Rest4 B5FLT B5FLT A4 D5 E5FLT D5 A4 D5 E5FLT D5];
a_7 = [G5 D5 G4 D4   G5 D5 G4 B4FLT  A5 C5 A4 C4  A5 C5 A4 C5   B5FLT B4FLT B3FLT D4   B5FLT B4FLT A4 G4    A4 A4 A4 A4 F5SHP F5SHP F5SHP F5SHP];

b_6 = [D3 G2 Rest4 D3 G2 Rest4 D3 G2 C3 F2SHP Rest4 C3 F2SHP Rest4 C3 F2SHP B2FLT D2 Rest4 B2FLT D2 Rest4 G2 G2 A2 F2SHP E2FLT D2 A2 F2SHP E2FLT D2];
b_7 = [D3 G2  D3 G2  D3 G2  D3 G2  C3 F2SHP C3 F2SHP C3 F2SHP C3 F2SHP  B2FLT G2  B2FLT G2  B2FLT G2  B2FLT G2  F2SHP A2 C3 C3 D3 F3SHP A3 A3];


%sound([a_y])
%sound([a_5,a_x])
song = [a,a_1,a_2,a_3,a_4,a_5,a_6,a_7;b,b_1,b_2,b_3,b_4,b_5,b_6,b_7];

sound([song,song,song,song,song,song,song,song,song,song])

bass = [];
treb = [];
y = [];
x = [];
a = [];
a_1 = [];
a_2 = [];
a_3 = [];
a_4 = [];
a_5 = [];
a_6 = [];
a_7 = [];
b = [];
b_1 = [];
b_2 = [];
b_3 = [];
b_4 = [];
b_5 = [];
b_6 = [];
b_7 = [];
song = [];





