%Must be the same as old monster 3
%A harder monster as a consequence for not getting a key.
Type = 3;
Action = 1;
sword = 0;
defense = 0;
defense_second = 0;
MonsterHP = 45;
Playerturn = 0;
Turn = 0;
Prestrike = 0; %-----Dictates if monster strikes premptively
Prestrike = randi([1 10],1);
%% Player turn
clc
imshow('Monster3.png','InitialMagnification','fit')
run('Battle_song')
while MonsterHP >=0 && Health >=0
    sword = 0;
    while Playerturn==0
        if Health<=(MaxHP*0.2)
            %I have to find a way to play low health, but not constantly
            %clear the sound, just the battle song music
        clear sound
        run('Battle_song_low')
        fprintf('Warning!!! You''re at very low health!!!!\n')
        end
run('Player_Options')
% if rem(Turn,999)==0 && Turn~=0 %Measure to counter attack
%     clc
%     fprintf('\nThe monster attacks preemtively!\n')
%     if defense==1
%     Monster_att = randi([1 2],1);
%     fprintf('But you defended.\n');
%     fprintf('The Monster pounds against the shield!\n')
%     end
%     if defense==0
%     Monster_att=randi([9 11],1);
%     end
%     Health = (Health-Monster_att);
%     damage = fprintf('You lose %4.2f HP!\n',Monster_att);
%     if MonsterHP <=0 || Health <=0
%     run('deadcheck')
%     break
%     end
% end
        if sword ==0
        enter = input('End of your turn\n', 's');
        clc
        else
        if sword == high
            fprintf('You swing with all your might! Critical damage!\n');
        end
        response = fprintf('You do %4.2f damage!\n',sword);
        enter = input('End of your turn\n', 's');
        clc
        MonsterHP = MonsterHP-sword;
        end

if MonsterHP <=0 || Health <=0
    break
end
   fprintf('The monster is about to attack!\n')
   fprintf('Choose your second action\n\n')
run('Player_Options_2')
%%%%%%%Place Previous IF Statement HERE%%%%%%%%%%

    end
%% Monster Turn
    if MonsterHP <=0 || Health <=0
    run('deadcheck')
    break
    end
if defense==1
    Monster_att = randi([1 2],1);
    fprintf('\n\nThe monster charges!\n');
    fprintf('But you defended.\n');
    fprintf('The monster pounds against the shield!\n')
end
if defense==0 && defense_second==0
    fprintf('The monster charges!\n');
    Monster_att=randi([9 11],1);
end
if defense_second==1
    fprintf('The monster charges!\n')
    Monster_att = floor(randi([9 11])./2);
    defense_second=0;
end
Health = (Health-Monster_att);
damage = fprintf('You lose %4.2f HP!\n',Monster_att);
input('','s')

if MonsterHP <=0 || Health <=0
    run('deadcheck')
    break
end
        if sword ==0
        clc
        else
        fprintf('You counterattack.\n')
        response = fprintf('You do %4.2f damage!\n',sword);
        MonsterHP = MonsterHP-sword;
        end

if MonsterHP <=0 || Health <=0
    run('deadcheck')
    break
end
enter = input('Continue to start your turn.\n','s');
Playerturn=0;
clc       
end


