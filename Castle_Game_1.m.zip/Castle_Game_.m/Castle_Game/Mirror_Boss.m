%The monster has an inventory, it is a copy of the players plus one item.
%(Bomb = Bomb + 1)


Action = 1;
sword = 0;
defense = 0;
defense_second = 0;
MonsterHP = 100;
Playerturn = 0;
%%%%SET TURN VALUE BACK TO 0 WHEN DONE
Turn = 0;
Type = 2;

Monster_Bomb = Bomb + 1;
Monster_Potion = Potion + 1;
Monster_Strength_Potion = Strength_Potion + 1;
Inv_att = 0

%% Player turn
clc
% run('Mirror_Song')
imshow('Monster2.jpg','InitialMagnification','fit')
while MonsterHP >=0 && Health >=0
    sword = 0;
%     I'm supressing the low health song for the mirror boss because the
%     song is so long. - Daniel Graciano
%     while Playerturn==0
%         if Health<=(MaxHP*0.2)
%             %I have to find a way to play low health, but not constantly
%             %clear the sound, just the battle song music
%         clear sound
%         run('Battle_song_low')
%         fprintf('Warning!!! You''re at very low health!!!!\n')
%         end
run('Player_Options')
if rem(Turn,2)==0 && Turn~=0 %-----If met, monster DEFENDS preemptively
    clc
    if defense==0 && sword~=high%
    Monst_Def = 1;
    sword = randi([1 2],1);
    fprintf('\nThe monster quickly puts up its shield in defense!\n')
    fprintf('Your sword pounds against ???''s shield.\n');
    end
    
    if MonsterHP <=0 || Health <=0
    run('deadcheck')
    break
    end
end
        if sword ==0
        enter = input('End of your turn\n', 's');
        clc
        elseif sword == high
            fprintf('You swing with all your might! Critical damage!\n');
        else
        response = fprintf('You do %4.2f damage!\n',sword);
        enter = input('End of your turn\n', 's');
        clc
        MonsterHP = MonsterHP-sword;
        end
        
if MonsterHP <=0 || Health <=0
    break
end
   fprintf('??? is about to attack!\n')
   fprintf('Choose your second action\n\n')
run('Player_Options_2')
%%%%%%%Place Previous IF Statement HERE%%%%%%%%%%


%% Monster Turn
%Inventory attack
if rem(Turn,4)==0 && Turn~=0
    Inv_att=1;
    if MonsterHP <=35 && Monster_Potion>0 && Turn~=0
        
        Monster_Potion = Monster_Potion - 1;
        MonsterHP = MonsterHP + 30;
        Monster_att = 0;
        fprintf('He takes out a potion and drinks it!\n\n')
        fprintf('???: Its a good thing you had one of these, haha\n!')
    elseif MonsterHP>35 && Monster_Bomb>0 && defense==0 && Turn~=0
        Monster_Bomb = Monster_Bomb - 1;
        Monster_att = 20;
        fprintf('Instead of attacking, ??? goes into his inventory for something...\n')
        fprintf('He pulls out a bomb and throws it at you!\n\n')
        fprintf('???:  Man, you have everything in here! Hahaha!\n')
    elseif MonsterHP>35 && Monster_Bomb>0 && defense==1 && Turn~=0
        fprintf('He does so with a wild smile in his eyes')
        Monster_Bomb = Monster_Bomb - 1;
        Monster_att = 0;
        fprintf('He pulls out a bomb and throws it at you!\n\n')
        fprintf('But you put up your shield just in time to avoid getting hit!\n')
        fprintf('???: Lucky punk! You really do know everything I''m going to do!\n')
    else
        fprintf('Frustrated, he throws his bag on the ground...')
    end

end

if MonsterHP <=0 || Health <=0
    run('deadcheck')
    break
end

%Monster  does extra damage to players who defend
% if defense==1 && rem(Turn,2)==0 && Turn~=0
%     Monster_att = randi([9 11],1);
%     fprintf('\n\nThe monster attacks.\n')
%     fprintf('You raise up your shield in defense.\n')
%     input('But the monster quickly flinches and strikes you from behind!\n','s')
% end
%Monster does normal damage when not defending
if defense==0 && defense_second==0 && rem(Turn,4)==0
    fprintf('The ??? attacks!\n');
    Monster_att=randi([5 8],1);
end
%Text if player defends
if defense_second==1 && rem(Turn,4)==0
    fprintf('The ??? attacks!\n')
    fprintf('You attempt to quickly defend yourself.\n')
    Monster_att = floor(randi([4 8])./2);
    defense_second=0;
end
% Text will only display if the monster deals damage to the player

if Monster_att>0
Health = (Health-Monster_att);
damage = fprintf('You lose %4.2f HP!\n',Monster_att);
input('','s')
elseif Monster_att<0
end

%To check if the player is dead
if MonsterHP <=0 || Health <=0
    run('deadcheck')
    break
end

if defense==1
    Monster_att = randi([1 2],1);
    fprintf('\n\n??? charges!\n');
    fprintf('But you defended.\n');
    input('His sword pounds against the shield!\n','s')
end

%If the player defends, the text for damage does not show up. If they
%attack, fprintf shows how much damage has been done.
        if sword ==0
        clc
        else
        fprintf('You counterattack.\n')
        response = fprintf('You do %4.2f damage!\n',sword);
        MonsterHP = MonsterHP-sword;
        end
%Checks again if the player or monster is dead
if MonsterHP <=0 || Health <=0
    run('deadcheck')
    break
end

if rem(Turn,4)==0 && Turn~=0 && MonsterHP<=35 && Inv_att==0
    fprintf('The ??? reaches into its inventory...\n')
    fprintf('He does so with a worried expression on his face...\n')
    
elseif rem(Turn,4)==0 && Turn~=0 && MonsterHP>35 && Inv_att==0
    fprintf(' The ??? reaches into its inventory..\n')
    fprintf('He does so with a wild expression in his eyes\n')
end
Inv_att=0;




enter = input('Continue to start your turn.\n','s');
Playerturn=0;
clc       
end

% Turn based attacks:
%   Every 5 turns, the monster will check it's health. If it's health is too
%   low, it will drink a potion from the inventory. If it's health is at a
%   certain value or higher, it will attack with a bomb from the inventory
%   EVERY time it goes into the inventory, the player will know what
%   happens based on fprintf
%
%   Every 3 turns, the monster will defend during the players first attack
%   move. To ensure it will not happen at the same time as the inventory
%   attack move, the monsters act of defending will only be during the
%   first attack move, and the inventory attack the second attack move.
%   (AKA needs to be set as a preemptive attack)

%   IF the player drinks a strength potion, the monster will mimic this and
%   drink a potion too. Within 1 or 2 turns of the player drinking the person.



